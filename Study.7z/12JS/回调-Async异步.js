/*
JS回调：
    回调 (callback) 是作为参数传递给另一个函数的函数
    这种技术允许函数调用另一个函数
    回调函数可以在另一个函数完成后运行

JS异步:
    与其他函数并行运行的函数称为异步（asynchronous）
等待超时:
在使用 JavaScript 函数 setTimeout() 时，可以指定超时时执行的回调函数
    setTimeout(myFunction, 3000);

    function myFunction() {
    document.getElementById("demo").innerHTML = "I love You !!";
    }

等待间隔：
在使用 JavaScript 函数 setInterval() 时，可以指定每个间隔执行的回调函数
    setInterval(myFunction, 1000);

    function myFunction() {
    let d = new Date();
    document.getElementById("demo").innerHTML=
    d.getHours() + ":" +
    d.getMinutes() + ":" +
    d.getSeconds();
    }

等待文件:
如果您创建函数来加载外部资源（如脚本或文件），则在内容完全加载之前无法使用这些内容。
此例加载一个 HTML 文件 (mycar.html)，并在文件完全加载后在网页中显示该 HTML 文件：
    function myDisplayer(some) {
    document.getElementById("demo").innerHTML = some;
    }

    function getFile(myCallback) {
    let req = new XMLHttpRequest();
    req.open('GET', "mycar.html");
    req.onload = function() {
        if (req.status == 200) {
        myCallback(this.responseText);
        } else {
        myCallback("Error: " + req.status);
        }
    }
    req.send();
    }

    getFile(myDisplayer);
*/

/*
JSPromise 包含两部分：
    "Producing code（生产代码）" 是需要一些时间的代码
    "Consuming code（消费代码）" 是必须等待结果的代码
    Promise 是一个 JavaScript 对象，它链接生成代码和消费代码

语法:
    let myPromise = new Promise(function(myResolve, myReject) {
         // "Producing Code"（可能需要一些时间）
    myResolve(); // 成功时
    myReject();  // 出错时
    });
        // "Consuming Code" （必须等待一个兑现的承诺）
    myPromise.then(
    function(value) {  成功时的代码 },
    function(error) {  出错时的代码  }
    );
    当执行代码获得结果时，它应该调用两个回调之一：

对象属性：
JavaScript Promise 对象可以是：Pending  Fulfilled Rejected
Promise有两个属性： state        result
                 "pending"	   undefined
                 "fulfilled"	   结果值
                 "rejected"	   error 对象
无法直接访问属性，必须使用Promise方法来处理Promise
即上面的Cosuming Code

实例：
等待超时：
    let myPromise = new  Promise(function(myResolve,myReject){
    setTimeout(function(){
        myResolve("I love You !!"); //回调函数  作为参数传入
    }, 3000);
    });

    myPromise.then(function(value){
        document.getElementById("demo").innerHTML = value;
        }
    );

等待文件：
    let myPromise = new Promise(function(myResolve, myReject) {
    let req = new XMLHttpRequest();
    req.open('GET', "mycar.htm");
    req.onload = function() {
        if (req.status == 200) {
        myResolve(req.response);
        } else {
        myReject("File not Found");
        }
    };
    req.send();
    });

    myPromise.then(
    function(value) {myDisplayer(value);},
    function(error) {myDisplayer(error);}
    );

*/

/*
JSAsync：
    函数前的关键字async 使函数返回 Promise
    
实例：
    async function myFunction() {
    return "Hello";
    }
等同于返回了一个promise
    async function myFunction() {
    return Promise.resolve("Hello");
    }
使用Promise方法来处理返回值
    myFunction().then(
    function(value) {myDisplayer(value);},
    function(error) {myDisplayer(error);}
    );

JSawait:
    函数前的关键字await 使函数等待 Promise

let value = await promise;
await 关键字只能在 async 函数中使用。

基础语法：可用于简写Promise语法
    async function myDisplay() {
    let myPromise = new Promise(function(myResolve, myReject) {
        myResolve("I love You !!");
    });
    document.getElementById("demo").innerHTML = await myPromise;
    }

    myDisplay();

实例：
等待超时：
    async function myDisplay() {
    let myPromise = new Promise(function(myResolve, myReject) {
        setTimeout(function() { myResolve("I love You !!"); }, 3000);
    });

    document.getElementById("demo").innerHTML = await myPromise;
    }

    myDisplay();

等待文件：
    async function getFile() {
    let myPromise = new Promise(function(myResolve, myReject) {
        let req = new XMLHttpRequest();
        req.open('GET', "mycar.html");
        req.onload = function() {
        if (req.status == 200) {myResolve(req.response);}
        else {myResolve("File not Found");}
        };
        req.send();
    });
    document.getElementById("demo").innerHTML = await myPromise;
    }

    getFile();
*/