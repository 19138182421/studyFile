/**防抖与节流
 * 防抖：当用户过于频繁触发一个事件时  只取最后一次操作  即间隔时间内用户再次触发则重新计时
 * 节流：当用户频繁点击时 为该事件设置节流 即间隔时间后再取用户的操作 在该间隔时间内不重复执行该事件
 * 
 * 实现：
 * 防抖的实现原理： 如搜索框
 *    读取input元素  let inp = document.querySelector("input");
 *    设置timer      let timer = null;
                    inp.oninput = function(){
                        if(timer !== null){
                              clearTimeout(timer);
                         }
                         timer = setTimeout(() => {
                            console.log(this.value);
                        }, 500);
                    }

  优化：使用闭包  业务逻辑与防抖函数要进行隔离开来  需要使用闭包和回调函数
       即封装一个防抖方法 事件的监听只需要调用这个方法并传入所需参数即可
      读取input元素  let inp = document.querySelector("input");
      书写业务逻辑   inp.oninput = debounce(function(){
                         //业务逻辑  即防抖结束后需要执行的操作  比如开始搜索等
                         //此时函数中的this指向为window
                       }, 500);               
      封装debounce   function debounce(fnc,delay){
      设置timer         let timer = null;  //设置为内部变量  即减少全局变量
                        return function(){
                            if(timer !== null){
                              clearTimeout(timer);
                         }
                         timer = setTimeout(() => {
                            func.call(this);  //业务逻辑函数 此时如果直接调用的话是由window来调用的 而不是input标签
                            //需要使用call方法来改变this的指向
                        }, delay);
                        }
                     }
 *   
 * 节流的实现原理：控制执行的次数
 * 节流锁
 *   let lock = true;
 *   
 *   在执行时间函数中判断lock并设置为false  一段时间后再设为true
 *   if(lock){
 *       setTimeout(() => {
             console.log("sdf");
             lock = true;
         }, 500); 
 *   }
 *   lock = false;
 * 
 *优化：
   1.设置事件监听函数:  元素.addEventListener("click",throttle(执行函数，延迟时间));
   2.设置节流函数：      function throttle(func ,delay){
                       let lock = true;
                       if(lock){ 
                           //定时执行操作并开锁
                           setTimeout(() => {
                               func.call(this);
                               lock = true;
                           }, delay);
                       }
                       lock = false; //关锁
                     }
    3.设置业务逻辑函数：function 执行函数(){
                       //事件监听要执行的操作
                      }

    window.onscroll = throttle(function(){
            //业务逻辑
    } , 500);

    function throttle(func , delay){
        let lock = true;
        return  function(){
            if(lock){
                setTimeout(() => {
                    func.call(this);
                    lock = true;
                }, delay);
            }
            lock = false;
        }
    }
 * 
 */