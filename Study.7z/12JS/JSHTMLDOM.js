/*
JSDOM：文档对象模型document
      当网页加载时，浏览器会创建页面的文档流对象模型，
      HTML DOM模型被结构化为对象树。
      JS可以通过这个对象模型获得创建动态HTML的所有功能。
            JavaScript 能改变页面中的所有 HTML 元素
            JavaScript 能改变页面中的所有 HTML 属性
            JavaScript 能改变页面中的所有 CSS 样式
            JavaScript 能删除已有的 HTML 元素和属性
            JavaScript 能添加新的 HTML 元素和属性
            JavaScript 能对页面中所有已有的 HTML 事件作出反应
            JavaScript 能在页面中创建新的 HTML 事件
什么是DOM？
    DOM 定义了访问文档的标准：
    “W3C 文档对象模型（DOM）是中立于平台和语言的接口，它允许程序和脚本动态地访问、更新文档的内容、结构和样式。”
    W3C DOM 标准被分为 3 个不同的部分：
        Core DOM - 所有文档类型的标准模型
        XML DOM  - XML文档的标准模型
        HTML DOM - HTML文档的标准模型

HTML DOM 是 HTML 的标准对象模型和编程接口。它定义了：
    作为对象的 HTML 元素
    所有 HTML 元素的属性
    访问所有 HTML 元素的方法
    所有 HTML 元素的事件
换言之：HTML DOM 是关于如何获取、更改、添加或删除 HTML 元素的标准

在DOM中，所有的HTML被定义为对象，DOM编程界面是每个对象的属性和方法。
HTML DOM属性：能够设置或改变的 HTML 元素的值
HTML DOM方法：能够（在 HTML 元素上）执行的动作

实例：document.getElementById("demo").innerHTML = "Hello World!";
      方法：getElementById("demo") 获取id为demo的HTML元素
      属性：innerHTML  获取或替换HTML元素的内容
   
HTML DOM 文档对象是网页中所有其他元素对象的拥有者。
HTML DOM Document对象：代表的是网页，访问页面中的所有元素都需要从访问document对象开始。

查找元素：
    document.getElementById(id)	            通过元素 id 来查找元素
    document.getElementsByTagName(name)	    通过标签名来查找元素
    document.getElementsByClassName(name)	通过类名来查找元素
    document.querySelectorAll("p.intro")    通过CSS选择器查找元素
    document.forms["frm1"]                  通过 HTML 对象选择器查找 HTML 对象


添加和删除元素：
    document.createElement(element)	创建 HTML 元素
    document.removeChild(element)	删除 HTML 元素
    document.appendChild(element)	添加 HTML 元素
    document.replaceChild(element)	替换 HTML 元素
    document.write(text)	        写入 HTML 输出流（输出到HTML页面上）
注意：千万不要在文档加载后使用 document.write()。这么做会覆盖文档

改变元素：
    element.innerHTML = new html content	改变元素的 inner HTML
    element.attribute = new value	        改变 HTML 元素的属性值
    element.setAttribute(attribute, value)	改变 HTML 元素的属性值
    element.style.property = new style    	改变 HTML 元素的样式
实例：document.getElementById("myImage").src = "landscape.jpg";



添加事件处理程序：
document.getElementById(id).onclick = function(){code}	向 onclick 事件添加事件处理程序

查找HTML对象属性：
    document.cookie	            返回文档的 cookie	
    document.doctype	        返回文档的 doctype	
    document.documentElement	返回 <html> 元素	
    document.documentMode	    返回浏览器使用的模式	
    document.documentURI	    返回文档的 URI
（剩余部分查文档获取）

JS表单验证：
    HTML 表单验证可以通过 JavaScript 完成。
    如果表单域 (fname) 为空，该函数会提示一条消息，并返回 false，以防止表单被提交
实例：
        function validateForm() {
        let x = document.forms["myForm"]["fname"].value;
        if (x == "") {
            alert("Name must be filled out");
            return false;
        }
        }

        <form name="myForm" action="/action_page.php" onsubmit="return validateForm()" method="post">
        Name: <input type="text" name="fname">
        <input type="submit" value="Submit">
        </form>

自动表单验证required属性：
    由浏览器自动执行
    如果表单字段 (fname) 为空，则 required 属性会阻止提交此表单：
    <form action="/action_page.php" method="post">
    <input type="text" name="fname" required>
    <input type="submit" value="Submit">
    </form>

HTML 约束验证：
HTML5 引入了一种新的 HTML 验证概念，称为约束验证。
HTML 约束验证基于：
    约束验证 HTML input 属性
    约束验证 CSS 伪选择器
    约束验证 DOM 属性和方法     
*/

/*
JS动画：
     1.创建动画容器：所有动画都应该跟容器元素关联
       <div id ="container">
         <div id ="animate">我的动画在这里。</div>
        </div>
     2.为元素添加样式：
       容器元素设为relative；
       动画元素设为absolute；
     3.动画代码：
        JavaScript 动画是通过对元素样式进行渐进式变化编程完成的。
        这种变化通过一个计数器来调用。
        当计数器间隔很小时，动画看上去就是连贯的。
        设置事件处理程序代码：
        function myMove() {
            var elem =  document.getElementById("animate"); 
            var pos = 0;
            var id = setInterval(frame, 5);
            function frame() {
                if (pos ==  350) {
                    clearInterval(id);
                } else {
                    pos++; 
                    elem.style.top = pos + 'px'; 
                    elem.style.left = pos + 'px'; 
                }
                }
            }
*/

/*
JS HTML DOM事件：
    1.向 button 元素分配 onclick 事件：
      <button onclick="displayDate()">试一试</button>
    2.为 button 元素指定 onclick 事件：
        <script>
        document.getElementById("myBtn").onclick = displayDate;
        </script> 

onload 和 onunload 事件：      
    当用户进入后及离开页面时，会触发 onload 和 onunload 事件。
    onload 事件可用于检测访问者的浏览器类型和浏览器版本，然后基于该信息加载网页的恰当版本。
    onload 和 onunload 事件可用于处理 cookie。

onchange 事件：
    onchange 事件经常与输入字段验证结合使用。
    下面是一个如何使用 onchange 的例子。当用户改变输入字段内容时，会调用 upperCase() 函数。
    <input type="text" id="fname" onchange="upperCase()">

onmouseover 和 onmouseout 事件：
    onmouseover 和 onmouseout 事件可用于当用户将鼠标移至 HTML 元素上或移出时触发某个函数：

onmousedown, onmouseup 以及 onclick 事件：
    onmousedown, onmouseup 以及 onclick 事件构成了完整的鼠标点击事件。
    首先当鼠标按钮被点击时，onmousedown 事件被触发；然后当鼠标按钮被释放时，onmouseup 事件被触发；最后，当鼠标点击完成后，onclick 事件被触发。

onfocus事件：
    当输入字段获取焦点时

事件监听程序：
      为HTML元素添加事件的另一种方法
    1.addEventListener() 方法为元素附加事件处理程序而不会覆盖已有的事件处理程序。
    2.能够向一个元素添加多个事件处理程序。
    3.能够向一个元素添加多个相同类型的事件处理程序，例如两个 "click" 事件。
    4.能够向任何 DOM 对象添加事件处理程序而非仅仅 HTML 元素，例如 window 对象。
    5.addEventListener() 方法使我们更容易控制事件如何对冒泡作出反应。
    6.当使用 addEventListener() 方法时，JavaScript 与 HTML 标记是分隔的，已达到更佳的可读性；即使在不控制 HTML 标记时也允许您添加事件监听器。
    7.能够通过使用 removeEventListener() 方法轻松地删除事件监听器。

语法：element.addEventListener(event, function, useCapture);
    第一个参数是事件的类型（比如 "click" 或 "mousedown"）。
    第二个参数是当事件发生时我们需要调用的函数。
    第三个参数是布尔值，指定使用事件冒泡还是事件捕获。此参数是可选的。
    注意：请勿对事件使用 "on" 前缀；请使用 "click" 代替 "onclick"

向 Window 对象添加事件处理程序：
addEventListener() 允许您将事件监听器添加到任何 HTML DOM 对象上，比如 HTML 元素、HTML 对象、window 对象或其他支持事件的对象，比如 xmlHttpRequest 对象。
    添加当用户调整窗口大小时触发的事件监听器：
    window.addEventListener("resize", function(){
        document.getElementById("demo").innerHTML = sometext;
    });

事件冒泡还是事件捕获？
   规定先处理哪个元素的事件，默认值为false(冒泡)   true(捕获)
在冒泡中，最内侧元素的事件会首先被处理，然后是更外侧的
在捕获中，最外侧元素的事件会首先被处理，然后是更内侧的

*/

/*
JS节点：
    1.创建新节点：
        父元素.appendChild(新元素);//添加元素到尾部
        父元素.insertBefore(已存在子元素 , 新元素);//添加元素到首部
        先创建一个新元素，再将其添加到已存在的元素中
        实例：
        var para = document.createElement("p");//p节点
        var node = document.createTextNode("这是一个新的段落。");//文本节点
        para.appendChild(node);//添加新节点
        
        var element = document.getElementById("div1");
        element.appendChild(para);

    2.移除元素：需要知道该元素的父元素
        父元素.removeChild(要移除的子元素);
      扩展：可以利用子元素的parentNode属性找到父元素并使用
         var child = document.getElementById("p1");
         child.class="marked">parentNode.removeChild(child);

    3.替换元素：
       父元素.replaceChild(原元素, 新元素);

JS HTML DOM 节点列表：
        NodeList 对象是从文档中提取的节点列表（集合）。
        NodeList 对象与 HTMLCollection 对象几乎相同。
        如使用 getElementsByClassName() 方法，某些（老的）浏览器会返回 NodeList 对象而不是 HTMLCollection。
        所有浏览器都会为 childNodes 属性返回 NodeList 对象。
        大多数浏览器会为 querySelectorAll() 方法返回 NodeList 对象。
    实例：var myNodeList = document.querySelectorAll("p");
          //如需访问第二个 <p> 节点，您可以这样写：
          y = myNodeList[1];
        HTML DOM Node List 长度：
        length 属性定义节点列表中的节点数：  
        var myNodelist = document.querySelectorAll("p");
        document.getElementById("demo").innerHTML = myNodelist.length;




JS HTML DOM集合：
        HTMLCollection 对象：
            getElementsByTagName() 方法返回 HTMLCollection 对象。
            HTMLCollection 对象是类数组的 HTML 元素列表（集合）。
    实例：var x = document.getElementsByTagName("p");
          //如需访问第二个 <p> 元素，您可以这样写：
          y = x[1];

        HTML HTMLCollection 长度：
            length 属性定义了 HTMLCollection 中元素的数量
    实例：var myCollection = document.getElementsByTagName("p");
          document.getElementById("demo").innerHTML = myCollection.length;         

两者区别：
    Collection是 HTML元素的集合。
    NodeList 是文档节点的集合。

    访问 HTMLCollection 项目，可以通过它们的名称、id 或索引号。
    访问 NodeList 项目，只能通过它们的索引号。
    只有 NodeList 对象能包含属性节点和文本节点

    元素集合与节点列表都不是数组！
*/