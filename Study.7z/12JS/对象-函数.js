/*
JS对象:


Object.value(对象名); 将对象转换为数组显示
JSON.stringify(对象名);将对象转换为字符串显示

使用 Getter 和 Setter？
    它提供了更简洁的语法
    它允许属性和方法的语法相同
    它可以确保更好的数据质量
    有利于后台工作
 set lang(lang) {
    this.language = lang.toUpperCase();
  }
 get lang() {
    return this.language.toUpperCase();
  }
调用方式：person.lang; //不加括号  以属性的方式调用

对象构造器：
    
    function Person(first, last, age, eye) {
        this.firstName = first;
        this.lastName = last;
        this.age = age;
        this.eyeColor = eye;
    }
    var myMother = new Person("Steve", "Jobs", 56, "green");
    
对象原型: prototype属性

更改属性值：
Object.defineProperty(object, property, {value : value})
// 修改属性
Object.defineProperty(person, "language", {value : "NO"});

Map对象:
    Map 对象存有键值对，其中的键可以是任何数据类型。
    Map 对象记得键的原始插入顺序。
    Map 对象具有表示映射大小的属性。
创建Map对象：
    const apples = {name: 'Apples'};
    const bananas = {name: 'Bananas'};
    const oranges = {name: 'Oranges'};
    // 创建新的 Map
      1.const fruits = new Map();
        // Add new Elements to the Map
        fruits.set(apples, 500);
        fruits.set(bananas, 300);
        fruits.set(oranges, 200);
      2.const fruits = new Map([;
        [apples, 500],
        [bananas, 300],
        [oranges, 200]
        ]);


属性：
    size	返回 Map 中元素的数量。
方法：
    new Map()	创建新的 Map 对象。
    set()	    为 Map 对象中的键设置值。
    get()	    获取 Map 对象中键的值。
    entries()	返回 Map 对象中键/值对的数组。
    keys()	    返回 Map 对象中键的数组。
    values()	返回 Map 对象中值的数组。
    clear()  	删除 Map 中的所有元素。
    delete()	删除由键指定的元素。
    has()	    如果键存在，则返回 true。
    forEach()	为每个键/值对调用回调。

for ...of遍历：
    for (var [key, value] of myMap) {
    console.log(key + " = " + value);
    }

Map对象操作：
     1.Map与Array转换
     var kvArray = [["key1", "value1"], ["key2", "value2"]];
    // Map 构造函数可以将一个 二维 键值对数组转换成一个 Map 对象
    var myMap = new Map(kvArray);
    // 使用 Array.from 函数可以将一个 Map 对象转换成一个二维键值对数组
    var outArray = Array.from(myMap);

     2.Map的克隆
    var myMap1 = new Map([["key1", "value1"], ["key2", "value2"]]);
    var myMap2 = new Map(myMap1);
    console.log(original === clone); 
    // 打印 false。 Map 对象构造函数生成实例，迭代出新的对象。

     3.Map的合并
    var first = new Map([[1, 'one'], [2, 'two'], [3, 'three'],]);
    var second = new Map([[1, 'uno'], [2, 'dos']]);
    // 合并两个 Map 对象时，如果有重复的键值，则后面的会覆盖前面的，对应值即 uno，dos， three
    var merged = new Map([...first, ...second]);

Set对象:
    Set 是唯一值的集合。
    每个值在 Set 中只能出现一次。
    一个 Set 可以容纳任何数据类型的任何值。
    typeof Set返回object
创建Set：
        const a = "a";
        const b = "b";
        const c = "c";

        const letters = new Set();

        letters.add(a);
        letters.add(b);
        letters.add(c);

Array转Set：
       const letters = new Set(["a","b","c"]);
Set转Array：
       var Array = [...letters];
String转Set：
       var letters = new Set("hello");
       注意：Set 中 toString 方法是不能将 Set 转换成 String

方法：
    new Set()	创建新的 Set 对象。
    add()	    向 Set 添加新元素。
    clear()	    从 Set 中删除所有元素。
    delete()	删除由其值指定的元素。
    entries()	返回 Set 对象中值的数组。
    has()	    如果值存在则返回 true。
    forEach()	为每个元素调用回调。
    keys()	    返回 Set 对象中值的数组。
    values()	与 keys() 相同。
    size	    返回元素的个数。

Set对象操作：
      1.数组去重
        var mySet = new Set([1, 2, 3, 4, 4]);
        [...mySet]; // [1, 2, 3, 4]
      2.并集
        var a = new Set([1, 2, 3]);
        var b = new Set([4, 3, 2]);
        var union = new Set([...a, ...b]); // {1, 2, 3, 4}
      3.交集
        var a = new Set([1, 2, 3]);
        var b = new Set([4, 3, 2]);
        var intersect = new Set([...a].filter(x => b.has(x))); // {2, 3} 
      4.差集
        var a = new Set([1, 2, 3]);
        var b = new Set([4, 3, 2]);
        var difference = new Set([...a].filter(x => !b.has(x))); // {1}
*/

/*
JS函数:
        JavaScript 函数定义不会为参数（parameter）规定数据类型。
        JavaScript 函数不会对所传递的参数（argument）实行类型检查。
        JavaScript 函数不会检查所接收参数（argument）的数量.


        定义方法:
           1.function 函数名(参数){

           }
           2.var 函数名 = new Function(参数,"函数体");
           3.var 函数名 = function(参数){

           };
函数调用：
       1.作为一个函数调用
           function myFunction(a, b) {
                return a * b;
            }
            myFunction(10, 2);  

       2.函数定义为对象的方法调用
          var myObject = {
                firstName:"John",
                lastName: "Doe",
                fullName: function () {
                    return this.firstName + " " + this.lastName;
                }
            }
            myObject.fullName();

       3.使用构造函数调用  此时函数作为对象来使用，即创建一个对象
         function myFunction(arg1, arg2) {
                this.firstName = arg1;
                this.lastName  = arg2;
            }
            var x = new myFunction("John","Doe");
            x.firstName;       // 返回 "John"

        4.作为函数方法调用
           var person = {
                fullName: function(city, country) {
                    return this.firstName + " " + this.lastName + "," + city + "," + country;
                }
            }
            var person1 = {
            firstName:"Bill",
            lastName: "Gates"
            }
            person.fullName.call(person1, "Seattle", "USA");    
            person.fullName.apply(person1,["Seattle","USA"]);
      
        5.自调用函数：
                （function(){
                      //函数体
                })();

                (function () {
                    var counter = 0;
                    return function () {return counter += 1;}
                })();
        6.箭头函数：
          1.无参数  括号不可省略
            var 函数名 = () =>{

           }
          2.单个参数  括号可以省略
            var 函数名 = 参数 =>{

            }
          3.多个参数
            var 函数名 = (参数,参数){

            }
普通函数和箭头函数的区别：
1.this指向不同：
  普通函数指向调用它的作用域       会变
  箭头函数指向一直拥有它的作用域   window对象即使使用call()和apply()和bind()也无法改变
2.箭头函数不可用作构造函数
3.箭头函数没有原型对象prototype
4.箭头函数没有自己的arguments





call()和apply()的区别
        call() 方法分别接受参数。
        apply() 方法接受数组形式的参数。
        如果要使用数组而不是参数列表，则 apply() 方法非常方便。

在 JavaScript 严格模式下，如果 apply() 方法的第一个参数不是对象，则它将成为被调用函数的所有者（对象）。
在“非严格”模式下，它成为全局对象。

 */

/*
JS闭包：
    JavaScript 变量属于本地或全局作用域。
    全局变量能够通过闭包实现局部（私有）
    闭包指的是有权访问父作用域的变量的函数（即使在父函数关闭之后）
var add = (function () {
    var counter = 0;
    return function () {return counter += 1;}
})();
//这个自调用函数只运行一次。它设置计数器为零（0），并返回函数表达式。
add();
add();
add();

闭包的问题：
1.内存泄漏   闭包函数引用的变量无法主动释放  需要将其置为null  
2.this指向问题 闭包函数在window作用域下执行 this指向window

在循环中使用闭包函数

闭包的条件：
1.函数嵌套函数
2.内部函数调用外部函数变量
3.调用外部函数

应用：
1.模拟块级作用域  封装一段代码 模块化
2.储存外部函数变量
3.封装私有变量

let yy = (function(){
       let a = 10;
       let b = 20;
       function add(){
         return a+b;
       }
       function sub(){
         return a-b;
       }
       //返回一个对象
       return {
             add:add,
             sub:sub
       }
})();

let m = yy.add();
let n = yy.sub();

<div>
        <button>1</button>
        <button>2</button>
        <button>3</button>
        <button>4</button>
        <button>5</button>
    </div>
<script>
 var aDiv = document.getElementsByTagName('button');//获取多个div集合
        // for (var i = 0; i < aDiv.length; i++) {
        //     aDiv[i].index = i;  为对象添加属性
        //     aDiv[i].onclick = function (){
        //                alert(this.index);
        //     //普通函数 中的this指向调用它的对象   即button标签对象
        //     //箭头函数的this始终在定义函数的地方来找  即父作用域的this值  此处为window 箭头函数父作用域为for循环  for循环的this值指向window
        //     }
        // }
         //利用闭包实现
        for (var i = 0; i < aDiv.length; i++) {
              //在函数内部定义一个函数来调用这个i 这个i就不会被销毁 除非主动置空
               (function(i){//形参
                   aDiv[i].onclick = ()=>{
                         alert(i);
                   }
               })(i);//实参
        
        }
</script>
   
*/

/*
JS类：类中的语法必须以“严格模式”编写。与函数和其他 JavaScript 声明不同，类声明不会被提升
 class Car {
  constructor(name, year) {
    this.name = name;
    this.year = year;
  }
  //如果未定义构造函数方法，JavaScript 会添加空的构造函数方法
     constructor(){}  //构造方法
     method1(){}
     method2(){}
}

类继承：extends

static方法:
    static functionName(){
        代码块；
    }
只能通过类名调用。如需使用对象则作为参数传入。
*/

/*
new 运算符的操作：
var obj = new Person();
1.创建一个空对象   var obj = {}
2.将空对象的proto成员指向Person函数对象的prototype   obj.proro = Person.prototype;
3.Person函数对象的this指针替换为obj  再调用Person函数  
4.将obj返回作为新对象


new Person("cat:)={
    var obj={};
    obj.__proto__ = Person.prototype;
    var result = Person.call(obj,'cat');
    return typeof result==='object'?result:object
}

*/


