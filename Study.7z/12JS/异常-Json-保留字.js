/*
JS异常：throw和try to catch
    try 语句使您能够测试代码块中的错误。
    catch 语句允许您处理错误。
    throw 语句允许您创建自定义错误。
    finally 使您能够执行代码，在 try 和 catch 之后，无论结果如何。
 
    try {
        供测试的代码块
    } catch (error) {
        处理错误的代码
    }
    finally{
        无论结果如何均会执行
    }
JavaScript 实际上会创建带有两个属性的 Error 对象：name 和 message

        错误名	     描述
        EvalError	已在 eval() 函数中发生的错误
       （更新版本的 JavaScript 不会抛出任何 EvalError。请使用 SyntaxError 代替）
        RangeError	已发生超出数字范围的错误
        ReferenceError	已发生非法引用
        SyntaxError	已发生语法错误
        TypeError	已发生类型错误
        URIError	在 encodeURI() 中已发生的错误  URI编码

throw 语句允许您创建自定义错误，即抛出异常。
     throw "Too big";    // 抛出文本
     throw 500;          //抛出数字
*/

/*
JSthis关键字：
    JavaScript this 关键词指的是它所属的对象。
    它拥有不同的值，具体取决于它的使用位置：
        在方法中，this    指的是所有者对象。
        单独的情况下，this 指的是全局对象。[object Window]
        在函数中，this     指的是全局对象。[object Window]
        在函数中，严格模式下，this 是 undefined。
        在事件中，this 指的是接收事件的元素。

call() 和 apply() 方法是预定义的 JavaScript 方法。
它们都可以用于将另一个对象作为参数调用对象方法
像call() 和 apply() 这样的方法可以将 this 引用到任何对象。
        var person1 = {
        fullName: function() {
            return this.firstName + " " + this.lastName;
        }
        }
        var person2 = {
        firstName:"Bill",
        lastName: "Gates",
        }
        person1.fullName.call(person2);  // 会返回 "Bill Gates"
*/

/*
JS箭头函数：
        hello = function() {
        return "Hello World!";
        }

        hello = () => {
        return "Hello World!";
        }
注意：1.参数可以写到()中
      2.箭头函数没有对this的绑定，this关键字始终表示定义箭头函数的对象。
*/


/*
JSON:JavaScript Object Notation
    JSON 是轻量级的数据交换格式
    JSON 独立于语言 *
    JSON 是“自描述的”且易于理解
    JSON 是存储和传输数据的格式。
    JSON 经常在数据从服务器发送到网页时使用。
    JSON 格式是纯文本。读取和生成JSON数据的代码可以在任何编程语言编写的。
json实例：可以是一个对象也可以是数组等
'{
"employees":[
    {"firstName":"Bill", "lastName":"Gates"}, 
    {"firstName":"Steve", "lastName":"Jobs"},
    {"firstName":"Alan", "lastName":"Turing"}
]
}'  
//{"键":[{键值对,键值对}, {键值对,键值对}]}
注意：格式上与JS创建对象的代码相同。
     但键必须用引号包围。

var obj = {a: 'Hello', b: 'World'}; //这是一个js对象，注意js对象的键名也是可以使用引号包裹的,这里的键名就不用引号包含
var json = '{"a": "Hello", "b": "World"}'; //这是一个 JSON 字符串，本质是一个字符串

json转JS对象：JSON.parse();
    var text = '{ "employees" : [{ "firstName":"Bill" , "lastName":"Gates" },' +
    '{ "firstName":"Steve" , "lastName":"Jobs" },{ "firstName":"Alan" , "lastName":"Turing" } ]}';

    var obj = JSON.parse(text);

    <p id="demo"></p>
    <script>
    document.getElementById("demo").innerHTML =
    obj.employees[1].firstName + " " + obj.employees[1].lastName;
    </script> 

JS转json：JSON.stringify(obj);
*/

/*
JS注意:
    var x1 = {};           // 新对象
    var x2 = "";           // 新的原始字符串值
    var x3 = 0;            // 新的原始数值
    var x4 = false;        // 新的原始布尔值
    var x5 = [];           // 新的数组对象
    var x6 = /()/;         // 新的正则表达式
    var x7 = function(){}; // 新的函数对象

减少DOM元素访问：
    var obj;
    obj = document.getElementById("demo");
    obj.innerHTML = "Hello";

延迟JS加载：
   1.放在底部
   2.<script defer = "true"> </script>  
*/
