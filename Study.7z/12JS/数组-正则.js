/*
JS数组：
   1.创建数组：1.var cars = ["Saab", "Volvo", "BMW"];
            2.var cars = [
                    "Saab",
                    "Volvo",
                    "BMW" 
                ];
            3.var cars = new Array("Saab", "Volvo", "BMW");
            4.多维数组 var array = new Array([数组1],[数组2])
    注意：出于简洁、可读性和执行速度的考虑，请使用第一种方法（数组文本方法）。
 
   2.访问数组：通过下标索引号来引用某个数组元素。
           var name = cars[0];

    3.数组是一种特殊的对象  typeof返回值为object
    您可以在数组保存对象。您可以在数组中保存函数。你甚至可以在数组中保存数组：
        myArray[0] = Date.now;
        myArray[1] = myFunction;
        myArray[2] = myCars;
    注意：数组与对象的区别：
          在 JavaScript 中，数组使用数字索引。
          在 JavaScript 中，对象使用命名索引。
    
    4.数组的属性和方法：
       1.length属性返回数组长度
         数组名.length;
       2.遍历数组元素用for循环或者Array.foreach()函数
           fruits.forEach(myFunction);
            text += "</ul>";
       //foreach()中是一个方法来输出每一个数组元素，即对每一个元素调用该方法，myFunction是回调函数。
            function myFunction(value) {
            text += "<li>" + value + "</li>";
            }
    5.添加与删除元素：
          1.把数组作为栈来考虑，首部为栈底，尾部为栈顶。
            尾部添加：push();返回数组新长度
            尾部删除：pop();返回被移出的字符串
            首部添加：unshift(); 返回数组新长度
            首部删除：shift(); 返回被移出的字符串
          2.使用length属性，因为length永远大于数组最高索引下标号
            数组名[数组名.length] = "sdf";
          3.添加最高索引的元素可在数组中创建未定义的“洞”：
            var fruits = ["Banana", "Orange", "Apple", "Mango"];
            fruits[6] = "Lemon";                 // 向 fruits 添加一个新元素 (Lemon)
          4.使用delete运算符删除元素
            delete 数组名[下标];//不推荐使用，会留下空位，即剩余数组元素无法自动移位

    6.关联数组：具有命名索引的数组被称为关联数组（或散列）。
        JavaScript 不支持命名索引的数组。
        在 JavaScript 中，数组只能使用数字索引。

    7.识别数组：
        1.Array.isArray(数组名);
        2.创建自己的isArray()函数
          function isArray(x) {
            return x.constructor.toString().indexOf("Array") > -1;
              //判断数组的构造器的名称中是否包含Array字符串。
            }
        3.instanceof  实例运算符
          数组名  instanceof  Array;

    8.数组转换为字符串：
         1.toString();无参数
         2.join(); 参数代表分隔符。

    9.拼接数组：
      1.splice(拼接起始位置 , 删除多少元素 , 添加的新元素);   
            可以用来删除、添加、替换元素。
            返回一个新数组。
            注意：如果只有前两个参数，则可用来删除元素。
      2.concat();
            返回新数组且可以使用任意数量的数组参数。

    10.裁剪数组：
       slice(开始元素下标,结束元素下标); 返回新数组。
       注意：不包括结束下标元素。
            省略第二个参数表示截取剩余所有元素。
*/
/*
JS数组转换：
      toString();          将数组转换为字符串
      toLocaleString();    转换为本地格式字符串
      join();              用指定分隔符将数组转换为字符串。
*/
/*
JS数组排序方法:
   1.sort();  按字母顺序从小到大排序
   2.reverse(); 按字母顺序从大到小排序

   3.按数字大小排序：此时直接使用sort()会导致"25"大于"100"
     通过在sort()方法中添加一个比值函数来修正判断
     数组名.sort(function(a,b){return  a-b}); 升序
     数组名.sort(function(a,b){return  b-a}); 降序
   原理:当sort()函数比较a和b时会传给内部匿名函数，
        然后sort()根据返回的值的正负来对a和b进行排序
    4.随机顺序排序数组：
        var points = [40, 100, 1, 5, 25, 10];
        points.sort(function(a, b){return 0.5 - Math.random()});  
    5.查询数组最大最小值：
       1.建议先排序，在通过索引提取。
        Math.max()函数不支持传递数组，只接受明确数值的参数
        但可以通过apply把数组转变为参数来比较。
        同理Math.min()也是如此。

        function myArrayMax(arr) {
            return Math.max.apply(null, arr);
            //第一个参数代表对象  第二个参数指定数组
            Math.max.apply([1, 2, 3]) 等于 Math.max(1, 2, 3)。
        }
        2.自制函数：
          function myArrayMax(arr) {
                var len = arr.length
                var max = -Infinity;//max赋值为无穷小  min就赋值无穷大
                while (len--) {
                    if (arr[len] > max) {
                        max = arr[len];
                    }
                }
                return max;
            }
    6.对象数组排序：
      1.比较数值
        cars.sort(function(a, b){return a.year - b.year});
      2.比较字符串：
        cars.sort(function(a, b){
            var x = a.type.toLowerCase();
            var y = b.type.toLowerCase();
            if (x < y) {return -1;}
            if (x > y) {return 1;}
            return 0;
          });
*/

/*
JS数组迭代:
   1.Array.foreach(函数名);方法为每个数组元素调用一次函数（回调函数）
        //在遍历元素时使用过
    参数：项目值value, 项目索引index, 数组本身array
            var txt = "";
            var numbers = [45, 4, 9, 16, 25];
            numbers.forEach(myFunction);

            function myFunction(value) {
                  txt = txt + value + "<br>"; 
            }
    2.Array.map(); 用法类似于Array.foreach();
      对每个数组元素执行函数，不更改原数组，产生新数组且不对空数组执行函数。

    3.Array.filter();创建满足函数要求的新数组，用于筛选数组
      Array.every(); 与filter()类似。
      Array.some();  与filter()类似。

      Array.find();返回通过测试函数的第一个数组元素的值
         //filter的简洁版，只需找出第一个满足条件的元素，使用方法相同。
        Array.findIndex();返回元素索引下标。


    4.Array.reduce();产生新数组，可用于数求和
       var numbers1 = [45, 4, 9, 16, 25];
        var sum = numbers1.reduce(myFunction, 100);
        //参数100为初始值，可有可无
        function myFunction(total, value) {
            return total + value;
        }
    5.Array.reduceRight();与reduce类似，但是从右到左执行
    
    
    


    检索位置方法
    1.Array.indexOf(item,start);可以指定检索起始位置
       数组名.indexOf("sgdh"); 返回元素索引下标
      Array.lastIndexOf(item , start);从数组尾开始检索 

    
*/


/*
JS日期类：
   创建Date对象：var date = new Date();
   参数：1.空
         2.year month day hours minutes seconds milliseconds
         3.milliseconds  var d = new Date(100000000000);
         4.dateString   var d = new Date("October 13, 2014 11:13:00");

    方法：1.toString();输出格式：Fri Mar 25 2022 12:13:54 GMT+0800 (中国标准时间)
         2.toUTCString(); 输出格式：Fri, 25 Mar 2022 04:13:28 GMT
         3.toDateString(); 输出格式：Fri Mar 25 2022

    日期的格式：
    ******注意：0代表1月  11代表12月*******
         首选输入格式：YYYY-MM-DD 
                     var d = new Date("2018-02-19");

        日期和时间通过大写字母 T 来分隔。
               var d = new Date("2018-02-19T12:00:00-08:30");

        UTC 时间通过大写字母 Z 来定义。
        如果您希望修改相对于 UTC 的时间，请删除 Z 并用 +HH:MM 或 -HH:MM 代替
    
    日期获取方法：
        getDate()	以数值返回天（1-31）
        getDay()	以数值获取周名（0-6）
        getFullYear()	获取四位的年（yyyy）
        getHours()	获取小时（0-23）
        getMilliseconds()	获取毫秒（0-999）
        getMinutes()	获取分（0-59）
        getMonth()	获取月（0-11）
        getSeconds()	获取秒（0-59）
        getTime()	获取时间（从 1970 年 1 月 1 日至今）
********返回UTC格式只需要在get后面加上UTC即可********
    日期对象设置方法：
        setDate()	以数值（1-31）设置日
        setFullYear()	设置年（可选月和日）
        setHours()	设置小时（0-23）
        setMilliseconds()	设置毫秒（0-999）
        setMinutes()	设置分（0-59）
        setMonth()	设置月（0-11）
        setSeconds()	设置秒（0-59）
        setTime()	设置时间（从 1970 年 1 月 1 日至今的毫秒数）

    日期比较方法：
        只要用运算符>直接比较两个日期对象即可
*/

/*
JS数学Math类：Math对象没有构造函数。方法和属性是静态的。
        Math.E          // 返回欧拉指数（Euler's number）
        Math.PI         // 返回圆周率（PI）
        Math.SQRT2      // 返回 2 的平方根
        Math.SQRT1_2    // 返回 1/2 的平方根
        Math.LN2        // 返回 2 的自然对数
        Math.LN10       // 返回 10 的自然对数
        Math.LOG2E      // 返回以 2 为底的 e 的对数（约等于 1.414）
        Math.LOG10E     // 返回以 10 为底的 e 的对数（约等于 0.434）

        abs(x)	返回 x 的绝对值
        acos(x)	返回 x 的反余弦值，以弧度计
        asin(x)	返回 x 的反正弦值，以弧度计
        atan(x)	以介于 -PI/2 与 PI/2 弧度之间的数值来返回 x 的反正切值。
        atan2(y,x)	返回从 x 轴到点 (x,y) 的角度
        ceil(x)	对 x 进行上舍入
        cos(x)	返回 x 的余弦
        exp(x)	返回 Ex 的值
        floor(x)	对 x 进行下舍入
        log(x)	返回 x 的自然对数（底为e）
        max(x,y,z,...,n)	返回最高值
        min(x,y,z,...,n)	返回最低值
        pow(x,y)	返回 x 的 y 次幂
        random()	返回 0 ~ 1 之间的随机数
        round(x)	把 x 四舍五入为最接近的整数
        sin(x)	返回 x（x 以角度计）的正弦
        sqrt(x)	返回 x 的平方根
        tan(x)	返回角的正切

    随机数：1.生成一个处于min(包括)和max(不包括)中间的随机数
           function getRndInteger(min, max) {
                return Math.floor(Math.random() * (max - min) ) + min;
            }

            2.生成一个处于min(包括)和max(包括)中间的随机数
            function getRndInteger(min, max) {
                return Math.floor(Math.random() * (max - min + 1) ) + min;
            }
*/

/*
JS循环：
    for - 多次遍历代码块
    for/in - 遍历对象属性  for(属性名 in 对象名)
    for/of -遍历数组元素(也可以使用foreach()回调函数) for(迭代变量 of 可迭代对象)
    while - 当指定条件为 true 时循环一段代码块
    do/while - 当指定条件为 true 时循环一段代码块

    break 打破循环
    continue 打破当前一次循环

    循环可以命名，并使用break来准确打破
    Xunhuan:
    for (let index = 0; index < array.length; index++) {
        const element = array[index];
        for (let index = 0; index < array.length; index++) {
            const element = array[index];
            break Xunhuan; //打破外层循环。
        }
    }
*/

/*
JStypeof：

constructor 属性返回所有 JavaScript 变量的构造函数。
    "Bill".constructor                // 返回 function String()  {[native code]}
    (3.14).constructor                // 返回 function Number()  {[native code]}
    false.constructor                 // 返回 function Boolean() {[native code]}
    [1,2,3,4].constructor             // 返回 function Array()   {[native code]}
    {name:'Bill',age:19}.constructor  // 返回 function Object()  {[native code]}
    new Date().constructor            // 返回 function Date()    {[native code]}
    function () {}.constructor        // 返回 function Function(){[native code]}
*/

/*
JS正则表达式：
   常用于字符串方法：search()和replace();
    i	执行对大小写不敏感的匹配。	试一试
    g	执行全局匹配（查找所有匹配而非在找到第一个匹配后停止）。	试一试
    m	执行多行匹配。

    [abc]	查找方括号之间的任何字符。	试一试
    [0-9]	查找任何从 0 至 9 的数字。	试一试
    (x|y)	查找由 | 分隔的任何选项。

    \d	查找数字。	试一试
    \s	查找空白字符。	试一试
    \b	匹配单词边界。	试一试
    \uxxxx	查找以十六进制数 xxxx 规定的 Unicode 字符。

    n+	匹配任何包含至少一个 n 的字符串。	试一试
    n*	匹配任何包含零个或多个 n 的字符串。	试一试
    n?	匹配任何包含零个或一个 n 的字符串。

RegExp 对象是带有预定义属性和方法的正则表达式对象。
      匹配方法：1.test();  正则表达式.test("sdfs");  返回boolean值
               2.exec();  正则表达式.exec("sdfs");  返回找到的文本  未找到返回null
    
******字符串.match(正则表达式);  以数组形式返回匹配到的文本数组****
*/


