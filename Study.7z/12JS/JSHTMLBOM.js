/*
JS HTML BOM：浏览器对象模型window
浏览器对象模型（Browser Object Model (BOM)）允许 JavaScript 与浏览器对话
    所有浏览器都支持 window 对象。它代表浏览器的窗口。
    所有全局 JavaScript 对象，函数和变量自动成为 window 对象的成员。
    全局变量是 window 对象的属性。
    全局函数是 window 对象的方法。
    甚至（HTML DOM 的）document 对象也是 window 对象属性：
如：window.document.getElementById("header");等同于document.getElementById("header");

窗口尺寸：
    window.innerHeight - 浏览器窗口的内高度（以像素计）
    window.innerWidth - 浏览器窗口的内宽度（以像素计）
窗口方法：
    window.open() - 打开新窗口
    window.close() - 关闭当前窗口
    window.moveTo() -移动当前窗口
    window.resizeTo() -重新调整当前窗口

JS Window Screen：window.screen 对象包含用户屏幕的信息。（可以省略前缀）
    screen.width         屏幕宽度
    screen.height        屏幕高度 
    screen.availWidth    可用宽度  减去诸如窗口工具条之类的界面特征
    screen.availHeight   可用高度  减去诸如窗口工具条之类的界面特征
    screen.colorDepth    屏幕色深  色彩分辨率的位数
    screen.pixelDepth    像素深度  对于现代计算机，颜色深度和像素深度是相等的。


JS Window Location：window.location 对象可用于获取当前页面地址（URL）并把浏览器重定向到新页面。
    window.location.href        返回当前页面的 href (URL)
    window.location.hostname    返回 web 主机的域名
    window.location.pathname    返回当前页面的路径或文件名
    window.location.protocol    返回使用的 web 协议（http: 或 https:）
    window.location.assign      加载新文档

JS Window History：window.history 对象包含浏览器历史
    history.back()    - 等同于在浏览器点击后退按钮
    history.forward() - 等同于在浏览器中点击前进按钮

JS Window Navigator：window.navigator 对象包含有关访问者的信息
    navigator.cookieEnaled   判断cookie是否已启用
    navigator.appName        返回浏览器的应用程序名称：
    navigator.appCodeName    返回浏览器的应用程序代码名称
    navigator.platform       返回浏览器引擎的产品名称
    navigator.appVersion     返回有关浏览器的版本信息
    navigator.userAgent      返回由浏览器发送到服务器的用户代理报头（user-agent header）
    navigator.platform       返回浏览器平台（操作系统）
    navigator.language       返回浏览器语言
    navigator.onLine         判断浏览器是否在线
    navigator.javaEnabled()  判断java是否启用
注意：来自 navigator 对象的信息通常是误导性的，不应该用于检测浏览器版本，因为：
        不同浏览器能够使用相同名称
        导航数据可被浏览器拥有者更改
        某些浏览器会错误标识自身以绕过站点测试
        浏览器无法报告发布晚于浏览器的新操作系统

JS 弹出框：警告框、确认框和提示框
警告框：window.alert("sometext");或者alert("sometext");
确认框：window.confirm("sometext");或者confirm("sometext");   如果用户单击“取消”，该框返回 false
提示框：window.prompt("sometext","defaultText");或者prompt("sometext","defaultText");   如果用户单击“取消”，该框返回 NULL
注意：如需要换行只需在文本中输入\n换行符即可


JS Timing事件：定时事件
    window 对象允许以指定的时间间隔执行代码。这些时间间隔称为定时事件。
方法：setTimeout(function,milliseconds);  在等待指定时间后执行
     setInterval(function,milliseconds);  在等待时间间隔后重复执行
注意：setTimeout() 和 setInterval() 都属于 HTML DOM Window 对象的方法。


如何停止执行？
      clearTimeout(timeoutVariable);
      clearInterval(timeVariable);
实例：myVar = setTimeout(function,2000);
     clearTimeout(myVar);

     myVar = setInterval(function, milliseconds);
     clearInterval(myVar);


JS Cookie:
   什么是cookie？
   Cookie是在计算机上存储在小的文本文件中的数据，当web服务器向浏览器发送网页后，连接被关闭，服务器会忘记用户的一切
   cookie就是为记住用户信息而发明的
        当用户访问网页时，用户名可以存储在cookie中
        下次访问时，cookie会记住该用户名，用键值对存储。
    当浏览器从服务器请求一个网页时，将属于该页的cookie添加到该请求中，这样服务器就获得了必要的数据来记住用户的信息
    
通过JS创建cookie：
    document.cookie = "username=Bill Gates; expires=Sun, 31 Dec 2017 12:00:00 UTC; path=/";
                       名值对  过期时间  路径
    通过 path 参数，您可以告诉浏览器 cookie 属于什么路径。默认情况下，cookie 属于当前页

通过JS获取cookie：
    document.cookie 会在一条字符串中返回所有 cookie
    比如：cookie1=value; cookie2=value; cookie3=value;

通过JS改变cookie：
    创建一个新的cookie，覆盖旧的cookie。

通过JS删除cookie：
    直接把 expires 参数设置为过去的日期即可：
    document.cookie = "username=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    应该定义 cookie 路径以确保删除正确的 cookie。
    如果不指定路径，一些浏览器允许删除 cookie。

Cookie字符串：
    即使你向 document.cookie 写一份完整的 cookie 字符串，当再次读取时，你只能看到它的名称-值对。
    如：cookie1 = value; cookie2 = value;

实例：访客第一次到达网页时，会要求他填写姓名。然后将该名称存储在 cookie 中。
      下次访客到达同一页时，他将收到一条欢迎消息。
    设置三个函数：
        设置 cookie 值的函数
        获取 cookie 值的函数
        检查 cookie 值的函数
function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
} 

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
         }
         if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
            //此处截取的是cookie的值  
         }
     }
    return "";
} 

function checkCookie() {
    var username = getCookie("username");
    if (username != "") {
        alert("Welcome again " + username);
    } else {
        username = prompt("Please enter your name:", "");
        if (username != "" && username != null) {
            setCookie("username", username, 365);
            //设置365天后清除
        }
    }
} 

*/