/*
Web API 是开发人员的梦想。
    它可以扩展浏览器的功能
    它可以极大简化复杂的功能
    它可以为复杂的代码提供简单的语法
    

什么是 Web API？
    API 指的是应用程序编程接口（Application Programming Interface）。
    Web API 是 Web 的应用程序编程接口。
    浏览器 API 可以扩展 Web 浏览器的功能。
    服务器 API 可以扩展 Web 服务器的功能。
    
浏览器API：
    所有的浏览器都自带一组内置的web pai来支持复杂的操作，并帮助访问数据。
    如：利用Geolocation api可以返回浏览器的坐标。
    <script>
    const x = document.getElementById("demo");

    function getLocation() {
    try {
        navigator.geolocation.getCurrentPosition(showPosition);
        //浏览器自己调用api获取位置信息，同时调用由自己编写的方法来显示
    } catch {
        x.innerHTML = err;
    }
    }

    function showPosition(position) {
    x.innerHTML = "Latitude: " + position.coords.latitude + 
    "<br>Longitude: " + position.coords.longitude;
    }
    </script>

第三方api：
    从web下载代码。
YouTube API - 允许您在网站上显示视频。
Twitter API - 允许您在网站上显示推文。
Facebook API - 允许您在网站上显示 Facebook 信息。
*/

/*
JS验证api：
    约束验证dom的方法：
          1.checkValidity()      如果input元素包含有效数据，则返回true
          2.setCustomValidity()  设置input元素的validationMessage属性
    约束验证 DOM 属性：
    validity	包含与输入元素有效性相关的布尔属性。
    validationMessage	包含当有效性为 false 时浏览器将显示的消息。
    willValidate	指示是否将验证 input 元素。      

*/

/*
Web History API：
    提供了访问windows.history对象的简单方法。
    windows.history对象包含用户访问过的URL(网站)。

方法：
    -window.history.back()  加载window.history列表中的上一个URL
    -window.history.forward()  加载历史列表中的下一个 URL。
    -window.history.go()    从历史列表中加载一个特定的 URL

属性： 
    -length  返回历史列表中的 URL 数量。
*/

/*
Web Storage API：
    一种用于在浏览器中存储和检索数据的简单语法。
            属性        	描述
window.localStorage	    允许在 Web 浏览器中保存键/值对。存储没有到期日期的数据。
window.sessionStorage	允许在 Web 浏览器中保存键/值对。存储一个会话的数据。

localStorage对象：
    localStorage 对象提供对特定网站的本地存储的访问。它允许您存储、读取、添加、修改和删除该域的数据项。
    存储的数据没有到期日期，并且在浏览器关闭时不会被删除。
    这些数据将在几天、几周和几年内均可用。
方法：
    -setItem()  将数据项存储在storage中，接收一个名称和一个值作为参数。
          localStorage.setItem("name", "Bill Gates");
    -getItem()  从存储(storage)中检索数据项。
          localStorage.getItem("name");

sessionStorage对象：
    不同之处在于 sessionStorage 对象存储会话的数据。
    当浏览器关闭时，数据会被删除。
方法一样。

其他属性/方法：
    属性/方法	                 描述
    key(n)          	    返回存储中第 n 个键的名称。
    length	                返回存储在 Storage 对象中的数据项数。
    getItem(keyname)	    返回指定的键名的值。
    setItem(keyname, value)	将键添加到存储中，或者如果键已经存在，则更新该键的值。
    removeItem(keyname)	    从存储中删除该键。
    clear()	                清空所有键。
*/

/*
Web Worker 是在后台运行的 JavaScript，不会影响页面的性能。
什么是 Web Worker？
    在 HTML 页面中执行脚本时，页面在脚本完成之前是无响应的。
    Web Worker 是在后台运行的 JavaScript，独立于其他脚本，不会影响页面的性能。
    用户可以继续做任何你想做的事情：点击、选取内容等，同时 web worker 在后台运行。
    通常 web worker 不用于简单的脚本，而是用于 CPU 密集型任务

1.使用前应先检测用户浏览器是否支持web worker：
    let  worker;
    if(typeof(worker)!== "undefined"){
        //yes  
        worker = new Worker("外部js文件");
    }else{
        //sorry! no web Worker support
    }
2.创建外部web Worker文件
    postMessage()用于将消息发送给HTML页面。
3.创建web Worker对象：
    let worker;
    worker = new Worker("外部js文件");
4.添加事件监听器：
    worker.onmessage = function(event){
       document.getElementById("id属性名").innerHTML = event.data;
       //当 Web Worker 发布消息时，将执行事件侦听器中的代码。
       //来自 Web Worker 的数据存储在 event.data 中。
    }
5.终止web worker：
    worker.terminate();
6.重用web worker(在它终止后，可以重用代码)：
    worker = undefined;

注意：由于web Worker位于外部文件中，所以无法使用js的window、document、parent对象。
*/

/*
JS Fetch API:
    Fetch API 接口允许 Web 浏览器向 Web 服务器发出 HTTP 请求。
    不再需要 XMLHttpRequest。

例如：获取文件并显示内容
    async function getText(file) {
        let myObject = await fetch(file);
        let myText = await myObject.text();
        myDisplay(myText);
    }

    getText("/demo/js/fetch_info.txt");
*/

/*
Web Geolocation API：
方法：getCurrentPosition(showPosition, showError) 方法用于返回用户的位置（参数为两个自定义方法）
     第二个参数用于处理错误。如果无法获取用户的位置，它规定要运行的函数
返回数据：
        coords.latitude	        以十进制数表示的纬度（始终返回）。
        coords.longitude	    以十进制数表示的经度（始终返回）。
        coords.accuracy	        位置精度（始终返回）。
        coords.altitude	        平均海平面以上的高度（以米计）（如果可用则返回）。
        coords.altitudeAccuracy	位置的高度精度（如果可用则返回）。
        coords.heading	        从北顺时针方向的航向（如果可用则返回）。
        coords.speed	        以米/秒计的速度（如果可用则返回）。
        timestamp	            响应的日期/时间（如果可用则返回）。

<script>
const x = document.getElementById("demo");
function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else {
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}

function showPosition(position) {
  x.innerHTML = "Latitude: " + position.coords.latitude +
  "<br>Longitude: " + position.coords.longitude;
}

function showError(error) {
  switch(error.code) {
    case error.PERMISSION_DENIED:
      x.innerHTML = "User denied the request for Geolocation."
      break;
    case error.POSITION_UNAVAILABLE:
      x.innerHTML = "Location information is unavailable."
      break;
    case error.TIMEOUT:
      x.innerHTML = "The request to get user location timed out."
      break;
    case error.UNKNOWN_ERROR:
      x.innerHTML = "An unknown error occurred."
      break;
  }
}
</script>
*/