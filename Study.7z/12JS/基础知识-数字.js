// JS作用:
/*1.直接写入HTML输出流
   document.write("<h1>这是一个标题</h1>"); 
  2.对事件反应
   <button type="button" onclick="alert('欢迎!')">点我!</button>
  3.改变HTML中的内容
    var x=document.getElementById("demo");  //查找元素
    x.innerHTML="Hello JavaScript";    //改变内容  
  4.改变HTML图像
    通过检索资源字符串中是否包含某个字符串
     function changeImage()
   {
    element=document.getElementById('myimage')
    if (element.src.match("bulbon"))
    {
        element.src="/images/pic_bulboff.gif";
    }
    else
    {
        element.src="/images/pic_bulbon.gif";
    }
     } 
  5.改变HTML样式
    var x=document.getElementById("demo")  //找到元素 
    x.style.color="#ff0000";           //改变样式  
  6.验证输入
    if(isNaN(x)||x.replace(/(^\s*)|(\s*$)/g,"")==""){
    alert("不是数字");
    }   
*/

/*
JS用法：
    1.在HTML页面文件的<head><body>中使用<script></script>标签包裹代码
    2.使用外部文件，在HTML页面文件的<script>中引用
    <script src="文件名"></script>
    注意：外部脚本中不能包含<script>标签。
*/

/*
JS输出：（JavaScript 没有任何打印或者输出的函数）
    使用 window.alert() 弹出警告框。
    使用 document.write() 方法将内容写到 HTML 文档中。如果在文档已完成加载后执行 document.write，整个 HTML 页面将被覆盖,即产生新的页面。
    使用 innerHTML 写入到 HTML 元素，document.getElementById("id属性值").innerHTML = "要修改的值";
    使用 console.log() 写入到浏览器的控制台
*/

/*
 var  let  const 区别
    1.var会变量声明提升，即先使用后声明，let、const则不可以。
    2.let声明的是局部变量，在代码块中生效。
    3.不写这三个则均定义为全局变量。
    4.const为常量，声明的同时必须赋值，不可更改数值，
    如果声明的是对象或者数组，不可以重新赋值，但可以通过属性名或下标来更改。
    5.var允许重复声明，let和const不允许重复声明
 */

/*
JS数据类型：
    6个基本数据类型：Number String Boolean Null Undefined Symbol(ES6引入，表示独一无二的值)
    引用数据类型：Object Array Function RegExp(正则表达式对象) Date

注意: 1.基本数据类型的变量存储在栈内存中。
      2.引用类型存储在堆内存中，但在栈内存中保存了变量名和堆内存地址。
        每一次new操作均会开辟出一块新的堆内存地址。


Undefined和Null的区别
    1.Undefined代表变量只声明但并未赋值。转换为Number为NaN。
    2.Null代表空对象引用。转换为Number为0。
    3.undefined和null基本相等但不全等。

声明数组的方式：
    1.var arr1 = new Array('a' , 'b' , 'c');
    2.var arr2 = ['a' , 'b' , 'c'];
    3.var arr3 = new Array();
      var arr4 = [];
      可以先创建空数组，再通过下标来填充数组。
    注意：数组的typeof返回值为object。
    判断是否为数组：
    1.arr1.isArray();返回值为boolean。
    2.arr1 instanceof Array;返回值为boolean。
                  

JS具有动态类型，即相同的变量可以用作不同的类型。可以使用typeof来检测数据类型。
*/

/*
JS对象：包含属性和方法
如： 1.var car = {name:"Fiat", model:500, color:"white"};
     2.var person = {
        firstName:"John",
        lastName:"Doe",
        age:50,
        eyeColor:"blue"
        };
    3.var person = new Object();
      person.name = 'as';
      person.age = '男';
      person.method = function(){
          方法体;
      }

属性:采用键值对的方式
   访问方式：
      1.对象名.属性名;
      2.对象名["属性名"]; 此种方式中括号中必须为字符串，不可直接用属性名。
    注意：     
    如果把符号用作对象的属性 / 键值，那么它会以一种特殊的方式存储，
    使得这个属性不出现在枚举中，要通过原型链上的函数 .getOwnPropertySymbols 才能找到：     
        var p = {
            foo: 16,
            [ Symbol( "bar" ) ]: "hello world",
            baz: true
        };
        Object.getOwnPropertyNames( p ); // [ "foo","baz" ]
        //如果要取得对象的符号属性：
        Object.getOwnPropertySymbols( p); // [ Symbol(bar) ]


方法：
     方法名:function(){
         方法体;
     }
    调用方式：
      1.对象名.方法名();返回方法执行结果
      2.对象名.方法名;将方法作为字符串返回，即function(){方法体;}
*/

/*
JS函数：
   function 函数名(参数){
       函数体;
   }

自调用函数：
(function () {
    var x = "Hello!!";      // 我将调用自己
})();
 */

/*
JS事件：
    HTML 事件可以是浏览器行为，也可以是用户行为。
    以下是 HTML 事件的实例：
    HTML 页面完成加载
    HTML input 字段改变时
    HTML 按钮被点击
    通常，当事件发生时，你可以做些事情。
    在事件触发时 JavaScript 可以执行一些代码。
    HTML 元素中可以添加事件属性，使用 JavaScript 代码来添加 HTML 元素。

JS中的两种写法：
  1.test.onclick = function changeContent(){
         //......
    }
  2.test.addEventListener("click",changeContent);//添加事件句柄
    //test.addEventListener("click",changeContent);//去除事件句柄 
    function changeContent(){
         //......
    }


注意：遵从“高内聚，低耦合”的编程原则，一般不建议在HTML元素中添加事件属性来添加属性。
    <button onclick="getElementById('demo').innerHTML=Date()">现在的时间是?</button>
*/

 /*
 JS字符串：
   1.使用单引号或双引号
   2.内建属性：length，返回字符串长度。
     用法: var str = "sadf";  typeof str 返回string
           var length = str.length;
   3.使用引号或其他特殊字符需要使用转义字符 \ 
   4.字符串换行推荐使用运算符 + 
   5.字符串也可以是对象(并不推荐)
     var str = new String("sdfs");  typeof str返回object;
 */

/*
JS字符串方法：

   //字符串检索
   1.indexOf() 返回某个字符串在整个字符串中首次出现的索引下标。
     var str = "The full name of China is the People's Republic of China.";
     var pos = str.indexOf("China");
   2.lastIndexOf() 返回最后一次出现的索引下标。
     var pos = str.lastIndexOf("China");
   注意：两种方法未找到时均返回 -1 
         两种方法均可接受第二个参数指定检索的开始位置。
   3.search() 搜索特定值的字符串，并返回匹配的位置
     var str = "The full name of China is the People's Republic of China.";
     var pos = str.search("locate");
     注意：indexOf()与search()方法有区别
         （1）indexOf方法不可使用正则表达式
         （2）search方法不可设置第二个参数即检索开始位置。

      match();根据正则表达式检索返回Array数组对象。    
             let str= "The rain in SPAIN stays mainly in the plain";
             str.match(/ain/g)    // 返回数组 [ain,ain,ain]

      includes();返回boolean值，判断字符串是否包含指定字符串
              let str = "Hello world, welcome to the universe.";
              str.includes("world")    // 返回 true
      
      startsWith()和endsWith()判断字符串是否以指定值开始和结尾。
          str.startsWith("dsj");
          str.endsWith("sadf");
      注意：startsWith()第二个参数代表检索的起始位置
            endsWith()第二个参数代表要检索的长度       

    4.提取部分字符串的方法
      (1)slice(start, end)
      (2)substring(start, end)
      (3)substr(start, length)
      省略第二个参数将截取剩余所有部分。
      
      提取字符串字符
      (1)charAt(); 返回指定下标的字符
      (2)charCodeAt();返回指定下标的字符的unicode编码

    5.替换字符串内容的方法
      repalce()用另一个值替换在字符串中指定的值
      var str = "Please visit Microsoft and Microsoft!";
      var newstr = str.replace("Microsoft", "W3School");
      注意：replace方法会产生一个新的字符串
           只会替换首个匹配
           对大小写不敏感
      还可以使用正则表达式
      var str = "Please visit Microsoft and Microsoft!";
      var newstr = str.replace(/Microsoft/ig, "W3School");
     6.大小写转换
       toUpperCase();
       toLowerCase();
     7.连接字符串
       concat(); 
        var text1 = "Hello";
        var text2 = "World";
        text3 = text1.concat(" ",text2);
     8.删除字符串两端空白符
       trim();
       var newstr = str.trim();  
     
     9.字符串转换为数组(字符串分裂)
       split("");
       var arr = str.split(" ");
       如果省略分隔符，被返回的数组将包含 index [0] 中的整个字符串。
       如果分隔符是 ""，被返回的数组将是间隔单个字符的数组：
*/
/*
JS字符串模板及模板字面量
   1.模板字面量使用反引号 ``来定义字符串
      let text = `Hello World!`;
   2.通过使用模板字面量，您可以在字符串中同时使用单引号和双引号，即不需要转义字符\
      let text = `He's often called "Johnny"`;
   3.允许多行字符串，类似于HTML中的pre标签

模板字面量提供了一种将变量和表达式插入字符串的简单方法。
语法: ${...}
   ...可以是变量、表达式。
主要作用即用...的真实值来插入值。
    let firstName = "John";
    let lastName = "Doe";
    let text = `Welcome ${firstName}, ${lastName}!`;

    let price = 10;
    let VAT = 0.25;
    let total = `Total: ${(price * (1 + VAT)).toFixed(2)}`;

    let header = "Templates Literals";
    let tags = ["template literals", "javascript", "es6"];
    let html = `<h2>${header}</h2><ul>`;
    for (const x of tags) {
        html += `<li>${x}</li>`;
    }
    html += `</ul>`;
*/

/*
JS数字的属性和方法：
  1.toString();  以字符串返回数值
    var x = 123;
    var str = x.toString();

  2.toExponential();返回字符串值，它包含已被四舍五入并使用指数计数法的数字
    参数为小数点后的字符数  返回科学计数法表示的值。

  3.toFixed();返回字符串值，它包含了指定位数小数的数字
    参数为指定位数小数的数字 返回字符串值
    toFixed(2);非常适合处理金钱。

  4.toPrecision();返回字符串值
    参数为整个数值的长度

  5.valueOf();以数值返回数值
    var x = 123;
    x.valueOf();  返回数值123
  每一个数据类型都有valueOf()和toString()方法。

  6.Number()	返回数字，由其参数转换而来。
    parseFloat()	解析其参数并返回浮点数。
    parseInt()	解析其参数并返回整数。
    注意：如果无法转换为数值，则返回 NaN (Not a Number)。
         parseFloat()会忽略字符串开头的0，十六进制均返回0
         parseInt()可以传入第二个参数来指定转换的进制。
         想要得到整数推荐优先使用parseInt();
         
属性：
MAX_VALUE	返回 JavaScript 中可能的最大数。
MIN_VALUE	返回 JavaScript 中可能的最小数。
NEGATIVE_INFINITY	表示负的无穷大（溢出返回）。
NaN	表示非数字值（"Not-a-Number"）。
POSITIVE_INFINITY	表示无穷大（溢出返回）。
*/ 