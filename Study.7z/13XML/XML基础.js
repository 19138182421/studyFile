/*
XML 指可扩展标记语言（EXtensible Markup Language）
 XML 不会做任何事情。XML 被设计用来结构化、存储以及传输信息。
XML被设计用来传输和存储数据，html被设计用来显示数据。

<?xml version="1.0" encoding="ISO-8859-1"?>

语法：
    1.所有 XML 元素都须有关闭标签
    2.XML 标签对大小写敏感
    3.XML 必须正确地嵌套
    4.XML 文档必须有根元素
    5.XML 的属性值须加引号
    6.实体引用
            &lt;	<	小于
            &gt;	>	大于
            &amp;	&	和号
            &apos;	'	单引号
            &quot;	"	引号
    7.在 XML 中，空格会被保留
    8.XML 以 LF 存储换行
        在 Windows 应用程序中，换行通常以一对字符来存储：回车符 (CR) 和换行符 (LF)。这对字符与打字机设置新行的动作有相似之处。
        在 Unix 应用程序中，新行以 LF 字符存储。
        而 Macintosh 应用程序使用 CR 来存储新行。

XML格式验证：DTD或者Schema  ******后续学习

XML样式：使用XSLT
    引入方式：<?xml-stylesheet type="text/xsl" href="simple.xsl"?>
注意：为避免不同浏览器显示问题建议在服务器上完成XSLT转换      ******后续学习
*/

/*
XMLHttpRequest对象：
        在不重新加载页面的情况下更新网页
        在页面已加载后从服务器请求数据
        在页面已加载后从服务器接收数据
        在后台向服务器发送数据
1.创建XMLHttpRequest对象
    xmlhttp = new XMLHttpRequest();
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");//老版本  兼容ie时
2.发送请求
    if (xmlhttp!=null)
    {
    xmlhttp.onreadystatechange = state_Change;  //事件句柄
        //onreadystatechange 是一个事件句柄。它的值 (state_Change) 是一个函数的名称，
        //当 XMLHttpRequest 对象的状态发生改变时，会触发此函数。
        // 状态从 0 (uninitialized) 到 4 (complete) 进行变化。仅在状态为 4 时，我们才执行代码。
    xmlhttp.open("GET",url,true);    参数：请求的方式  提交请求的地址  是否异步处理  
        //True 表示脚本会在 send() 方法之后继续执行，而不等待来自服务器的响应。
        //false 可以省去额外的 onreadystatechange 代码。如果在请求失败时是否执行其余的代码无关紧要，那么可以使用这个参数。
    xmlhttp.send(null);
    }
*/

/*
XML解析器：
    解析器把XML转换为XML DOM对象即可通过JS操作的对象。
1.解析文档：
    xmlhttp.open("GET","xx.xml",false);
    xmlhttp.send(null);
    xmlDoc = xmlhttp.repsonseXML;
  其他浏览器方法：
    微软：
    var xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
    xmlDoc.async="false";  关闭异步加载，这样确保在文档完全加载之前解析器不会继续脚本的执行
    xmlDoc.load("note.xml");
    Firefox等：
    var xmlDoc=document.implementation.createDocument("","",null);
    xmlDoc.async="false";  关闭异步加载，这样确保在文档完全加载之前解析器不会继续脚本的执行
    xmlDoc.load("note.xml");
2.解析字符串：
     parser = new DOMParser();
     xmlDoc = parser.parseFromString(字符串变量,"text/xml");
  其他浏览器方法：
     xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
     xmlDoc.async="false";
     xmlDoc.loadXML(txt);  loadXML() 方法用于加载字符串（文本），load() 用于加载文件
*/

/*
HTML DOM：定义了访问和操作html文档的标准方法
例如：document.getElementById("to").innerHTML=
     document  HTML文档对象
     getElementById("name")  获取元素
     innerHTML   HTML元素的内部文本


XML DOM：定义了访问和操作xml文档的标准方法
    把XML文档当作树结构来查看，元素的文本、属性都被认为是节点。
例如：xmlDoc.getElementsByTagName("to")[0].childNodes[0].nodeValue
    xmlDoc  由解析器创建的XML文档
    getElementByTagName("name")[n]  第n个<name>元素
    childNodes[n] <name>元素的第一个子元素（文本节点）
    nodeValue     节点的值

*/

/*
XML to HTML：
    xmlhttp.open("GET","cd_catalog.xml",false);
    xmlhttp.send();
    xmlDoc=xmlhttp.responseXML;

    document.write("<table border='1'>"); 创建表格
    var x=xmlDoc.getElementsByTagName("CD");  读取元素
    for (i=0;i<x.length;i++)  
    {
    document.write("<tr><td>");  创建行列
    document.write(x[i].getElementsByTagName("ARTIST")[0].childNodes[0].nodeValue);
    document.write("</td><td>");
    document.write(x[i].getElementsByTagName("TITLE")[0].childNodes[0].nodeValue);
    document.write("</td></tr>");
    }
    document.write("</table>");
*/

/*
XML 应用程序：

*/

/*
XML命名空间：提供避免元素命名冲突的方法。

*/